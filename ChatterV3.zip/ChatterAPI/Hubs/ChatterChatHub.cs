﻿using ChatterChatHandler;
using Microsoft.AspNetCore.SignalR;

namespace ChatterAPI.Hubs;

public class ChatterChatHub : Hub
{
    public Task SendMessage(WriteToChatMessage message)
    {
        return Clients.All.SendAsync("ReceiveMessage", message);
    }
}